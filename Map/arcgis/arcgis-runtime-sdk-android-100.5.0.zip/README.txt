Welcome to the ArcGIS Runtime SDK for Android!

v100.5.0

----------------------------
Overview
----------------------------
The ArcGIS Runtime SDK for Android provides you with the API libraries required to build ArcGIS apps for the Android platform. Please reference the install and setup doc on the ArcGIS Runtime SDK for Android developers site for the most up to date setup guide https://developers.arcgis.com/android/latest/guide/install-and-set-up.htm

----------------------------
Release Notes
----------------------------
Please reference the release notes on the ArcGIS Runtime SDK for Android developers site for the most up to date release notes https://developers.arcgis.com/android/latest/guide/release-notes.htm

----------------------------
SDK Contents
----------------------------
The ArcGIS Runtime SDK for Android contains everything you need to develop ArcGIS Android apps.
The contents of the SDK are provided below:

 + doc > API reference doc for arcgis android api.
 + legal > All the SDK license information.
 + libs > Third party dependency jar libraries and the arcgis-android aar library module.

----------------------------
Requirements
----------------------------
Please reference the system requirements notes on the ArcGIS Runtime SDK for Android developers site for the most up to date requirements https://developers.arcgis.com/android/latest/guide/system-requirements.htm

----------------------------
Set up the ArcGIS Android SDK to work with local maven repository
----------------------------
1. Download the arcgis-runtime-sdk-android-100.5.0.zip file
2. Extract the contents of the archive to a location on disk
3. cd into the /libs/aar/ directory
4. Copy the contents of the libs/aar directory to the following location on your disk
    mac: /Users/[user-name]/.m2/repository/com/esri/arcgisruntime/arcgis-android/100.5.0/
6. Your full directory path should resemble the following:
	mac: 2 files:
	/Users/[user-name]/.m2/repository/com/esri/arcgisruntime/arcgis-android/100.5.0/arcgis-android-100.5.0.aar
	/Users/[user-name]/.m2/repository/com/esri/arcgisruntime/arcgis-android/100.5.0/arcgis-android-100.5.0.pom
7. Your local maven repo should be set, we will confirm in the next step.

----------------------------
Getting Started
----------------------------
1. Edit your build.gradle file to look at your local maven repository.
2. Add the following to your project root build.gradle file:


allprojects {
    repositories {
        mavenLocal()
    }
}

3. Add the following dependencies to your app's build.gradle file:

dependencies {
	...
    implementation 'com.esri.arcgisruntime:arcgis-android:100.5.0'
    implementation files('<path to unzipped arcgis-runtime-sdk-android-100.5.0>/libs/gson-2.8.5.jar')
}

Note: Only add the gson dependency if you are disconnected from the internet; otherwise, Gradle will download it automatically.

4. From here forward you only need to add the dependencies from step 3 when you create new app modules by adding it to your new app modules build.gradle file.
