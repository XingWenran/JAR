//>>built
define({popupLabel:"Zobrazit nebo skr\u00fdt sloupce"});