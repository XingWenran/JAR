//>>built
define({popupLabel:"Visa eller d\u00f6lj kolumner"});