//>>built
define({popupLabel:"Vis eller skjul kolonner"});