//>>built
define({popupLabel:"Wy\u015bwietl lub ukryj kolumny"});