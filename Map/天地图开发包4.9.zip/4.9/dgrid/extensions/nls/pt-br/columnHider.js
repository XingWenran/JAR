//>>built
define({popupLabel:"Mostrar ou ocultar colunas"});