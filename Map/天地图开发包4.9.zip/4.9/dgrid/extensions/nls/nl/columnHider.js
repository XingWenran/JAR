//>>built
define({popupLabel:"Kolommen weergeven of verbergen"});