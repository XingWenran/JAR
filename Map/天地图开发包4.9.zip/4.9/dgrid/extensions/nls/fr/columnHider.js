//>>built
define({popupLabel:"Afficher ou masquer les colonnes"});