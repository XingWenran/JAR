//>>built
define(["dojo/window","../main"],function(b,a){a.getDocumentWindow=function(a){return b.get(a)}});