//>>built
define(["../typematic"],function(){});