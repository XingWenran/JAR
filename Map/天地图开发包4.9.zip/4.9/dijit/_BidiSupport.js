//>>built
define(["dojo/has","./_WidgetBase","./_BidiMixin"],function(b,a,c){a.extend(c);b.add("dojo-bidi",!0);return a});